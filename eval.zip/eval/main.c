/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amathew <amathew@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/11 16:02:40 by amathew           #+#    #+#             */
/*   Updated: 2021/11/12 10:00:21 by amathew          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "ft_printf.h"

int	main(void)
{
	int	number;

	number = 42;
	ft_printf("%dtest\n", number);
	printf("%dtest\n", number);
	return (0);
}
 
//i = 0;
//format[i]
//i++